declare module "edge-tts-browser" {
  export interface EdgeTTSOptions {
    voice?: string;
    rate?: number;
    pitch?: number;
    volume?: number;
  }

  export class EdgeTTS {
    constructor(options?: EdgeTTSOptions);
    toAudio(text: string): Promise<Blob>;
    toStream(text: string): Promise<ReadableStream<Uint8Array>>;
  }
}
