import { EdgeTTS } from "edge-tts-browser";

/**
 * TTS 管理类，用于文本转语音
 * 使用 Microsoft Edge TTS 和台湾甜妹语音 (zh-TW-HsiaoChenNeural)
 */
export class TTSManager {
  private edgeTTS: EdgeTTS;
  private currentAudio: HTMLAudioElement | null = null;
  private isPlaying = false;
  private isPaused = false;

  constructor() {
    this.edgeTTS = new EdgeTTS({
      voice: "zh-TW-HsiaoChenNeural", // 台湾甜妹语音
      rate: 1.0,
      pitch: 0,
    });
  }

  /**
   * 朗读文本
   */
  async speak(text: string): Promise<void> {
    try {
      // 停止当前播放
      this.stop();

      // 生成语音
      const audioBlob = await this.edgeTTS.toAudio(text);
      const audioUrl = URL.createObjectURL(audioBlob);

      // 创建音频元素
      this.currentAudio = new Audio(audioUrl);
      this.isPlaying = true;
      this.isPaused = false;

      // 监听播放完成
      this.currentAudio.onended = () => {
        this.isPlaying = false;
        this.isPaused = false;
        URL.revokeObjectURL(audioUrl);
      };

      // 开始播放
      await this.currentAudio.play();
    } catch (error) {
      console.error("TTS 错误:", error);
      throw error;
    }
  }

  /**
   * 暂停播放
   */
  pause(): void {
    if (this.currentAudio && this.isPlaying) {
      this.currentAudio.pause();
      this.isPaused = true;
      this.isPlaying = false;
    }
  }

  /**
   * 继续播放
   */
  resume(): void {
    if (this.currentAudio && this.isPaused) {
      this.currentAudio.play();
      this.isPlaying = true;
      this.isPaused = false;
    }
  }

  /**
   * 停止播放
   */
  stop(): void {
    if (this.currentAudio) {
      this.currentAudio.pause();
      this.currentAudio.currentTime = 0;
      this.isPlaying = false;
      this.isPaused = false;
    }
  }

  /**
   * 获取播放状态
   */
  getState(): {
    isPlaying: boolean;
    isPaused: boolean;
  } {
    return {
      isPlaying: this.isPlaying,
      isPaused: this.isPaused,
    };
  }

  /**
   * 销毁 TTS 管理器
   */
  destroy(): void {
    this.stop();
    this.currentAudio = null;
  }
}

// 创建全局 TTS 实例
export const ttsManager = new TTSManager();
