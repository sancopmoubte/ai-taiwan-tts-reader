import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Volume2, MessageSquare, Zap } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useLocation } from "wouter";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  if (isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
        {/* 顶部导航 */}
        <div className="bg-white border-b border-slate-200 shadow-sm">
          <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
            <h1 className="text-2xl font-bold text-slate-900">
              AI 台湾甜妹语音朗读助手
            </h1>
            <div className="text-sm text-slate-600">
              欢迎, {user?.name || "用户"}
            </div>
          </div>
        </div>

        {/* 主要内容 */}
        <div className="max-w-6xl mx-auto px-4 py-16">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-slate-900 mb-4">
              开始您的 AI 对话之旅
            </h2>
            <p className="text-xl text-slate-600 mb-8">
              享受优雅精致的聊天体验，配合台湾甜妹语音朗读
            </p>
            <Button
              size="lg"
              className="px-8 py-6 text-lg"
              onClick={() => setLocation("/chat")}
            >
              <MessageSquare className="w-5 h-5 mr-2" />
              进入聊天
            </Button>
          </div>

          {/* 功能卡片 */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-12">
            <Card className="p-6 hover:shadow-lg transition-shadow">
              <MessageSquare className="w-8 h-8 text-blue-500 mb-4" />
              <h3 className="text-lg font-semibold text-slate-900 mb-2">
                AI 聊天
              </h3>
              <p className="text-slate-600">
                与强大的大模型进行自然对话，获得智能回复
              </p>
            </Card>

            <Card className="p-6 hover:shadow-lg transition-shadow">
              <Volume2 className="w-8 h-8 text-purple-500 mb-4" />
              <h3 className="text-lg font-semibold text-slate-900 mb-2">
                台湾甜妹语音
              </h3>
              <p className="text-slate-600">
                使用自然流畅的台湾甜妹语音朗读 AI 回复
              </p>
            </Card>

            <Card className="p-6 hover:shadow-lg transition-shadow">
              <Zap className="w-8 h-8 text-amber-500 mb-4" />
              <h3 className="text-lg font-semibold text-slate-900 mb-2">
                智能控制
              </h3>
              <p className="text-slate-600">
                灵活的播放控制和自动朗读开关，完全由您掌控
              </p>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center">
      <Card className="p-8 text-center max-w-md">
        <h1 className="text-3xl font-bold mb-4">AI 台湾甜妹语音朗读助手</h1>
        <p className="text-slate-600 mb-6 text-lg">
          体验优雅精致的 AI 聊天，享受台湾甜妹语音朗读
        </p>
        <Button
          className="w-full"
          size="lg"
          onClick={() => (window.location.href = getLoginUrl())}
        >
          登录开始
        </Button>
      </Card>
    </div>
  );
}
