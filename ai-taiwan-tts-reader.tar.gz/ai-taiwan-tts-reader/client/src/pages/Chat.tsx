import { useEffect, useRef, useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Spinner } from "@/components/ui/spinner";
import { Progress } from "@/components/ui/progress";
import { trpc } from "@/lib/trpc";
import { ttsManager } from "@/lib/tts";
import { Mic, Pause, Play, Square, Volume2, Send } from "lucide-react";
import { toast } from "sonner";

interface Message {
  id: number;
  role: "user" | "assistant";
  content: string;
  createdAt: Date;
}

export default function Chat() {
  const { user, isAuthenticated } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [autoSpeak, setAutoSpeak] = useState(() => {
    const saved = localStorage.getItem("autoSpeak");
    return saved !== null ? JSON.parse(saved) : true;
  });
  const [currentSpeakingId, setCurrentSpeakingId] = useState<number | null>(null);
  const [ttsState, setTtsState] = useState({ isPlaying: false, isPaused: false });
  const [streamingContent, setStreamingContent] = useState("");
  const [lastAssistantId, setLastAssistantId] = useState<number | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const getChatHistoryQuery = trpc.chat.getHistory.useQuery(undefined, {
    enabled: isAuthenticated,
  });

  // 加载聊天历史
  useEffect(() => {
    if (getChatHistoryQuery.data) {
      setMessages(
        getChatHistoryQuery.data.map((msg) => ({
          ...msg,
          createdAt: new Date(msg.createdAt),
        }))
      );
    }
  }, [getChatHistoryQuery.data]);

  // 自动滚动到底部
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, streamingContent]);

  // 保存自动朗读设置
  useEffect(() => {
    localStorage.setItem("autoSpeak", JSON.stringify(autoSpeak));
  }, [autoSpeak]);

  // 处理发送消息（使用 SSE 流式输出）
  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const userMessage = inputValue;
    setInputValue("");
    setIsLoading(true);
    setStreamingContent("");

    try {
      // 添加用户消息到本地状态
      const userMsg: Message = {
        id: Date.now(),
        role: "user",
        content: userMessage,
        createdAt: new Date(),
      };
      setMessages(prev => [...prev, userMsg]);

      // 调用 SSE 流式接口
      const response = await fetch("/api/stream-chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ message: userMessage }),
      });

      if (!response.ok) {
        throw new Error("Failed to send message");
      }

      const reader = response.body?.getReader();
      if (!reader) {
        throw new Error("No response body");
      }

      let fullContent = "";
      let messageId: number | null = null;

      // 读取 SSE 流
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        const chunk = new TextDecoder().decode(value);
        const lines = chunk.split("\n");

        for (const line of lines) {
          if (line.startsWith("data: ")) {
            try {
              const data = JSON.parse(line.slice(6));

              if (data.type === "start") {
                messageId = data.messageId;
              } else if (data.type === "chunk") {
                fullContent += data.content;
                setStreamingContent(fullContent);
              } else if (data.type === "done") {
                fullContent = data.message;
                setStreamingContent("");

                // 添加 AI 消息到本地状态
                const assistantMsg: Message = {
                  id: messageId || Date.now() + 1,
                  role: "assistant",
                  content: fullContent,
                  createdAt: new Date(),
                };
                setMessages(prev => [...prev, assistantMsg]);
                setLastAssistantId(assistantMsg.id);

                // 自动朗读最新 AI 回复
                if (autoSpeak) {
                  await handleSpeak(assistantMsg.id, fullContent);
                }
              } else if (data.type === "error") {
                toast.error(data.message || "发送消息失败");
              }
            } catch (e) {
              // 忽略解析错误
            }
          }
        }
      }

      // 刷新消息历史
      await getChatHistoryQuery.refetch();
    } catch (error) {
      toast.error("发送消息失败，请重试");
      console.error(error);
    } finally {
      setIsLoading(false);
      setStreamingContent("");
    }
  };

  // 朗读消息
  const handleSpeak = async (messageId: number, content: string) => {
    try {
      setCurrentSpeakingId(messageId);
      await ttsManager.speak(content);
      setTtsState(ttsManager.getState());
    } catch (error) {
      toast.error("朗读失败，请重试");
      console.error(error);
      setCurrentSpeakingId(null);
    }
  };

  // 暂停朗读
  const handlePause = () => {
    ttsManager.pause();
    setTtsState(ttsManager.getState());
  };

  // 继续朗读
  const handleResume = () => {
    ttsManager.resume();
    setTtsState(ttsManager.getState());
  };

  // 停止朗读
  const handleStop = () => {
    ttsManager.stop();
    setTtsState(ttsManager.getState());
    setCurrentSpeakingId(null);
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100">
        <Card className="p-8 text-center max-w-md">
          <h1 className="text-2xl font-bold mb-4">AI 台湾甜妹语音朗读助手</h1>
          <p className="text-slate-600 mb-6">
            请登录以开始使用聊天和语音朗读功能
          </p>
          <Button className="w-full" size="lg">
            登录
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex flex-col">
      {/* 顶部栏 */}
      <div className="bg-white border-b border-slate-200 shadow-sm sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-slate-900">
              AI 台湾甜妹语音朗读助手
            </h1>
            <p className="text-sm text-slate-500">
              {user?.name ? `欢迎, ${user.name}` : ""}
            </p>
          </div>

          {/* 自动朗读开关 */}
          <div className="flex items-center gap-3">
            <Label htmlFor="auto-speak" className="flex items-center gap-2 cursor-pointer">
              <Volume2 className="w-4 h-4 text-slate-600" />
              <span className="text-sm font-medium text-slate-700">自动朗读</span>
            </Label>
            <Switch
              id="auto-speak"
              checked={autoSpeak}
              onCheckedChange={setAutoSpeak}
            />
          </div>
        </div>
      </div>

      {/* 消息区域 */}
      <div className="flex-1 overflow-y-auto max-w-4xl mx-auto w-full px-4 py-6">
        <div className="space-y-4">
          {messages.length === 0 && !streamingContent ? (
            <div className="text-center py-12">
              <Mic className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-500 text-lg">
                开始对话，体验台湾甜妹语音朗读
              </p>
            </div>
          ) : (
            <>
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${
                    msg.role === "user" ? "justify-end" : "justify-start"
                  }`}
                >
                  <div
                    className={`max-w-xs lg:max-w-md xl:max-w-lg px-4 py-3 rounded-lg ${
                      msg.role === "user"
                        ? "bg-blue-500 text-white rounded-br-none"
                        : "bg-white text-slate-900 border border-slate-200 rounded-bl-none shadow-sm"
                    }`}
                  >
                    <p className="text-sm leading-relaxed">{msg.content}</p>

                    {msg.role === "assistant" && (
                      <div className="mt-2 flex items-center gap-2">
                        {currentSpeakingId === msg.id ? (
                          <>
                            {ttsState.isPlaying && !ttsState.isPaused ? (
                              <>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-8 w-8 p-0"
                                  onClick={handlePause}
                                >
                                  <Pause className="w-4 h-4" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-8 w-8 p-0"
                                  onClick={handleStop}
                                >
                                  <Square className="w-4 h-4" />
                                </Button>
                              </>
                            ) : ttsState.isPaused ? (
                              <>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-8 w-8 p-0"
                                  onClick={handleResume}
                                >
                                  <Play className="w-4 h-4" />
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-8 w-8 p-0"
                                  onClick={handleStop}
                                >
                                  <Square className="w-4 h-4" />
                                </Button>
                              </>
                            ) : null}
                          </>
                        ) : (
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-8 w-8 p-0"
                            onClick={() => handleSpeak(msg.id, msg.content)}
                          >
                            <Volume2 className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ))}

              {/* 流式输出内容 */}
              {streamingContent && (
                <div className="flex justify-start">
                  <div className="max-w-xs lg:max-w-md xl:max-w-lg px-4 py-3 rounded-lg bg-white text-slate-900 border border-slate-200 rounded-bl-none shadow-sm">
                    <p className="text-sm leading-relaxed">{streamingContent}</p>
                    <div className="mt-2 flex items-center gap-2">
                      <Spinner className="w-4 h-4" />
                      <span className="text-xs text-slate-500">朗读中...</span>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* 输入区域 */}
      <div className="bg-white border-t border-slate-200 shadow-lg sticky bottom-0">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex gap-2">
            <Input
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={(e) => {
                if (e.key === "Enter" && !isLoading) {
                  handleSendMessage();
                }
              }}
              placeholder="输入您的问题..."
              disabled={isLoading}
              className="flex-1"
            />
            <Button
              onClick={handleSendMessage}
              disabled={isLoading || !inputValue.trim()}
              className="px-6"
            >
              {isLoading ? (
                <>
                  <Spinner className="w-4 h-4 mr-2" />
                  发送中
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  发送
                </>
              )}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
