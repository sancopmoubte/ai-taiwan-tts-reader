import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import { getChatMessages, addChatMessage } from "./db";
import { invokeLLM } from "./_core/llm";
import type { Message } from "./_core/llm";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  chat: router({
    getHistory: protectedProcedure.query(async ({ ctx }) => {
      return getChatMessages(ctx.user.id, 100);
    }),

    sendMessage: protectedProcedure
      .input(z.object({ message: z.string().min(1) }))
      .mutation(async ({ ctx, input }) => {
        // Save user message
        await addChatMessage(ctx.user.id, "user", input.message);

        // Get LLM response
        const messages: Message[] = [
          {
            role: "system",
            content:
              "You are a helpful assistant. Respond in a friendly and concise manner. If the user writes in Chinese, respond in Chinese.",
          },
          {
            role: "user",
            content: input.message,
          },
        ];

        const response = await invokeLLM({ messages });

        // Extract content as string
        const content = response.choices[0]?.message?.content;
        const assistantMessage = typeof content === "string" 
          ? content 
          : (Array.isArray(content) 
              ? content.map(c => (typeof c === "string" ? c : c.type === "text" ? c.text : "")).join("")
              : "Unable to generate response");

        // Save assistant message
        await addChatMessage(ctx.user.id, "assistant", assistantMessage);

        return {
          message: assistantMessage,
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;
