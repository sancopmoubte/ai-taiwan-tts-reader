import { Request, Response } from "express";
import { sdk } from "./_core/sdk";
import { addChatMessage } from "./db";
import { invokeLLM } from "./_core/llm";
import type { Message } from "./_core/llm";

/**
 * 处理 SSE 流式输出
 * 接收用户消息，调用 LLM，并以 SSE 方式流式返回 AI 回复
 */
export async function handleStreamChat(req: Request, res: Response) {
  try {
    // 验证认证
    const user = await sdk.authenticateRequest(req);
    if (!user) {
      res.status(401).json({ error: "Unauthorized" });
      return;
    }

    const { message: userMessage } = req.body;
    if (!userMessage || typeof userMessage !== "string") {
      res.status(400).json({ error: "Invalid message" });
      return;
    }

    // 保存用户消息
    await addChatMessage(user.id, "user", userMessage);

    // 设置 SSE 响应头
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");
    res.setHeader("Access-Control-Allow-Origin", "*");

    // 调用 LLM
    const messages: Message[] = [
      {
        role: "system",
        content:
          "You are a helpful assistant. Respond in a friendly and concise manner. If the user writes in Chinese, respond in Chinese.",
      },
      {
        role: "user",
        content: userMessage,
      },
    ];

    const response = await invokeLLM({ messages });

    // 提取 AI 回复
    const content = response.choices[0]?.message?.content;
    const assistantMessage = typeof content === "string"
      ? content
      : (Array.isArray(content)
          ? content.map(c => (typeof c === "string" ? c : c.type === "text" ? c.text : "")).join("")
          : "Unable to generate response");

    // 保存 AI 回复到数据库
    await addChatMessage(user.id, "assistant", assistantMessage);

    // 以 SSE 方式流式发送回复
    // 首先发送开始信号
    res.write(`data: ${JSON.stringify({ type: "start" })}\n\n`);

    // 逐字符发送内容（模拟流式效果）
    for (let i = 0; i < assistantMessage.length; i++) {
      const chunk = assistantMessage[i];
      res.write(`data: ${JSON.stringify({ type: "chunk", content: chunk })}\n\n`);
      // 模拟流式延迟（可选，实际应用中可根据需要调整）
      await new Promise(resolve => setTimeout(resolve, 5));
    }

    // 发送完成信号
    res.write(`data: ${JSON.stringify({ type: "done", message: assistantMessage })}\n\n`);
    res.end();
  } catch (error) {
    console.error("Stream chat error:", error);
    res.write(`data: ${JSON.stringify({ type: "error", message: "Internal server error" })}\n\n`);
    res.end();
  }
}
